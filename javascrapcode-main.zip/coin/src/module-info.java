module coin {
}