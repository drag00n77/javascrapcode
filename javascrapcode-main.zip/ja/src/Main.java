
import java.util.Scanner;
public class Main
{
 
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
int min = 1;
 
int max = 13;
 
int score = 1000;
 
int output;
 
System.out.println("High Low Game\n\nRULES\nNumbers 1-6 are low\nNumbers 8-13 are high\nNumber 7 is neither high or low");
do {
System.out.println("\n\nYou have " + score + " points.\n\nEnter points to risk: ");
int player = input.nextInt();
while (player > score){
	//" player Enter a value correlating  score.");
player = input.nextInt();
}

System.out.print("\nPredict <1=High, 0=Low>: ");
int predict = input.nextInt();
 
int rand = (int)Math.floor(Math.random()*(max-min+1)+min);
System.out.println("Number is "+rand);
if (rand >= 1 && rand <= 6) {
output = 0;
} else if (rand >= 8 && rand <= 12) {
output = 1;
}else {
output = 9000;
}
 
if (predict == 1 && output == 1) {
System.out.println("You Win!");
score = (score + (player*2));
}else if (predict == 0 && output == 0) {
System.out.println("You Win!");
score = (score + (player*2));

}else if (rand == 7 ){
System.out.println("it is neither...");
score = (score-player);
System.out.println( score + " score is left " );
}else {
System.out.println("You lose.");
score = (score-player);
System.out.println( score + " score is left ");
}
 
System.out.printf("Play Again? (1:yes  2:no:) ");
int playAgain = input.nextInt();
if (score <= 0) {
System.out.println("You have no more points.");
break;
}else if (playAgain == 1){
}else {
break;
}
} while (score > 0);
 
System.out.println("Game Over.");
input.close();
}
}
