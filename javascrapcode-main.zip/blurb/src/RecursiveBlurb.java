
 import java.util.Random;

 

     public class RecursiveBlurb
     {

         Random chooser;

         public RecursiveBlurb()
         {
             chooser = new Random() ;
         }
         private String getWhoozitYs(){

             StringBuffer y = new StringBuffer();

             boolean stop = chooser.nextBoolean();
             if (!stop)
             y.append(getWhoozitYs());
             else
             return y.toString();

             y.append("y");
             return y.toString();
         }

         private String getWhoozit()
         {
             StringBuffer whoozit = new StringBuffer();
             whoozit.append("x");
             whoozit.append(getWhoozitYs());

             return whoozit.toString();

         }

         private String getWhatzit()
         {
             StringBuffer whatzit =new StringBuffer();
             whatzit.append("q");
             boolean z = chooser.nextBoolean();
             if (z)
             whatzit.append("z");
             else
             whatzit.append("d");

             whatzit.append(getWhoozit());

             return whatzit.toString();

         }

         private String getMultipleWhatzits()
         {
             StringBuffer whatzits =new StringBuffer();

             whatzits.append(getWhatzit());
             boolean stop = chooser.nextBoolean();
             if (!stop)
             whatzits.append(getMultipleWhatzits());
             else
             return whatzits.toString();

             return whatzits.toString();
         }
         
         public String generateBlurb()
         {
             StringBuffer blurb = new StringBuffer();
             blurb.append(getWhoozit());
             blurb.append(getMultipleWhatzits());

             return blurb.toString();
         }
         
         
     }
 
 