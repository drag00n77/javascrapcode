 import java.util.Scanner;


 public class MyProgram {

public static  void main (String args [])
         {
	
        	 RecursiveBlurb blurb=new RecursiveBlurb();
        	
        	 Scanner sc= new Scanner (System.in);
        	 System.out.println("Pick The Number Of Blurbs You Want(in ints)?");
        	int numBlurbs=sc.nextInt();
        	 
        	if(numBlurbs<0)
        		numBlurbs=0;
        	
        	for(int i=0; i<numBlurbs;i++) {
        		System.out.println("Blurb: "+blurb.generateBlurb());
            }
        	sc.close();
       }
   		
}
