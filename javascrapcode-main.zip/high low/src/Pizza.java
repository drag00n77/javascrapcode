import java.util.Scanner;
public class Pizza {
/* the  cost of 
  pizza*/ 
public static void   main(String[]args) {

Scanner input = new Scanner(System.in);
System.out.print("enter the diameter(the size) of pizza: ");
float a=input.nextFloat();
input.close(); 

float Pizza = (float) (.05*a*a);
float basic;
float labor =(float) .75; 
float bussiness = (float) 1.0 ;
basic = labor+bussiness;
float total = basic + Pizza;
 System.out.println( );
 System.out.println("the cost of making the pizza is: $"+total);
 }
}
