//import java.util.Collections;
//import java.util.List;

//Change the MagazineRack program (Listings 9.2, 9.3, and 9.4) by
//adding delete and insert operations into the MagazineList class.
//Have the Magazine class implement the Comparable interface,
//and have the insert method call the compareTo method in the
//Magazine class, which decides whether one Magazine title comes
//before another alphabetically. In the driver, use insertion and deletion operations. Print the list of magazines.


public class MagazineRack 
	{

	    public static void main (String[] args)

	   {
	   
	      MagazineList rack = new MagazineList();

	     
	      rack.delete (new Magazine("c"));
	      rack.insert (new Magazine("time")); //time

	      rack.insert (new Magazine("wired")); //Wired

	      rack.insert (new Magazine("Communications of the ACM")); //Communications of the ACM

	      rack.insert (new Magazine("House and Garden"));//House and Garden

	      rack.insert (new Magazine("GQ")); //GQ
	      //rack.delete (new Magazine("c"));
	      //rack.delete (new Magazine("b"));
	      System.out.println( "Before deletes:\n" + rack );

	      rack.delete (new Magazine("GQ"));
	      rack.delete (new Magazine("House and Garden"));
	       

	      
	 

	     System.out.println( "After deletes:\n" + rack );

	 

	      rack.insert (new Magazine("WHAT AM I DOING"));//WHAT AM I DOING

	      rack.insert (new Magazine("HELLO WORLD"));//HELLO WORLD

	      rack.insert (new Magazine("CHICKEN"));//CHICKEN

	      rack.insert (new Magazine("hello"));//hello
		
	 
  System.out.println( "After 2nd inserts:\n" + rack ); 

	   }

}

 

