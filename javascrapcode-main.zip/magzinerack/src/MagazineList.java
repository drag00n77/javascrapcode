public class MagazineList 
{
   private MagazineNode list;

   //----------------------------------------------------------------
   //  Sets up an initially empty list of magazines.
   //----------------------------------------------------------------
   public MagazineList()
   {
      list = null;
   }

  
   //----------------------------------------------------------------
   //  Creates a new MagazineNode object and adds it to the end of
   //  the linked list.
   //----------------------------------------------------------------
  
     
   
   //----------------------------------------------------------------
   //  Creates a new MagazineNode object and adds it to the its place
   //  in the linked list.
   //----------------------------------------------------------------
   public void insert (Magazine mag) {
   MagazineNode current;
   MagazineNode previous = null;
   boolean done= false;
   {
	   
        MagazineNode node = new MagazineNode(mag);
        node.next = list;
        list = node;
        if (list == null)
            list = node;
        else
        {
        	  current = list;
        	  
        	  while(!done) {
        		  int compareResult= current.magazine.compareTo(mag);
        		  if  (compareResult==0)//duplicate
        			  return;
        		  if (compareResult>0)
        		  {
        			  if(previous !=null)
        				  previous.next=node;
        				  else
        					  list=node;
        			  node.next=current;
        					  done=true;
        	  }
        		  
        		  
        		  
        	  
        	  else
        	  if (list == current)
        	  {
        		  node.next = current;
        		  list = node;
        	  }
        	  else
        	  {
        		  node.next = current.next;
        		  current.next = node;
        		  done=true;
        	  }
        		   
        			  if (current.next==null)
        		  {
        			current.next=node;
        			done=true;
        		  }
        			  else {
        				  previous=current;
        				  current=current.next;
        				  
        			  }
        	  }
        	  
   }
   }
   }
      	  
 	
        
  // public void deleteAll ()
   //{
     //  if(list != null)
       //     list = null;
   //}
    	  
   
   	//---------------------------------------------------------------
   	//  Deletes a magazine from the linked list
   	//---------------------------------------------------------------
   
	public boolean delete (Magazine mag)
   	{
		// MagazineNode node = new MagazineNode (mag); //a,b,b,c,b,d
    	 MagazineNode previous = list; //a
         MagazineNode current = list; //b
//System.out.println("ankit1");
//System.out.println(list.toString());


          if (list == null)
        	  
      	{	
    System.out.println("This is nothing to in the list to delete");
   // System.out.println("ankit2");
    }
         // else
        //  {
        	//  System.out.println("ankit3");
          //   while (current != null) {
            	
    	//	if (current.next == node ) 
    		//{ 
    			///run a delete operation
    		//	previous.next =current.next ; // b=b
    			
    			//break;
    			 
    //		}
            // previous=current.next;
             //}	
    			
    			
    			
    		//}

     //    }

if (current==null)
	return false;
while(current.next!=null) {
	if(current.magazine.compareTo(mag)==0) {
		if(previous!=null) 
		previous.next=current.next;
		else
			list=current.next;
		return true;
	}
	previous=current;
	current=current.next;
	}
return true;
}
          

      

   //----------------------------------------------------------------
   //  Returns this list of magazines as a string.
   //----------------------------------------------------------------
   public String toString ()
   {
      String result = "";

      MagazineNode current = list;

      while (current != null)
      {
         result += current.magazine + "\n";
         current = current.next;
      }

      return result;
   }

  
   private class MagazineNode
   {
      public Magazine magazine;
      public MagazineNode next;

      //--------------------------------------------------------------
      //  node
      //--------------------------------------------------------------
      public  MagazineNode (Magazine mag)
      {
       magazine = mag;
         next = null;
       	
         }
     // public String toString(){
     	// return "deleting" ;
       //}

      }
      
   }



	

   


   