package sportswork;

public class sportsabstract {
int win;
int lose;
int points;
int point;
}
