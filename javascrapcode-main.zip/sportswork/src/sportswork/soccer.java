package sportswork;

public class soccer extends sportsabstract {
	
String goalkeeper= "jon";
String scorer="tom";
public soccer(){
	win=(int) Math.floor(Math.random() * 101);
	points=win; 
	lose=(int) Math.floor(Math.random() * 101);
	point=lose;
	
}
public int  totalwin() {
	

return(points);
}
public int  totallose() {
	

return(point);
}

}
