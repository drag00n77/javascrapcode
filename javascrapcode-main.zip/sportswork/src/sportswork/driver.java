package sportswork;

public class driver {
	public static void main(String[] args) {
		football raven = new football();
		soccer usa = new soccer(); 
		System.out.println("Stats: football Team Raven Vs soccer Team Usa");
		System.out.println();
		System.out.println("Wins and Loses");
		System.out.println();
	System.out.println("the soccer team usa has won " +usa.totalwin()+" games.");
	System.out.println("the football team raven has won "+raven.totalwin()+" games.");
	System.out.println();
	System.out.println("the soccer team usa has lost " +usa.totallose()+" games.");
	System.out.println("the football team raven has lost " +raven.totallose()+" games.");
	System.out.println();
	System.out.println("the football team raven has played "+(raven.totallose()+raven.totalwin())+" games."  );
	System.out.println("the soccer team usa has played "+(usa.totallose()+usa.totalwin())+" games."  );
	
	System.out.println();
	System.out.println("the mvp of the soccer team usa is "+usa.scorer+".");
	System.out.println("the best defense of the soccer team usa is "+usa.goalkeeper+".");
	System.out.println("the best quaterback team raven is "+raven.quarterBack+".");
	System.out.println("the best defense of the soccer team usa is "+raven.kicker+".");
	}

}
