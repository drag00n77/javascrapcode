import java.util.Scanner;
import java.lang.Math;
public class dicrool {
	public static void main(String args[]) {
		Scanner input = new Scanner(System.in);
	    int a=0;
	    System.out.print("Enter the number of loops(positive): ");
		a=input.nextInt();
		input.close();
		
		
		System.out.println("dice 1          dice 2         total ");
			for (int i=1; i<=a; i++) {
				int q,p;
			q = (int) (6*Math.random()+1);
			p = (int) (6*Math.random()+1);
			 System.out.print("");
			System.out.println(""+ q + "               "+ p +"              "+ (q+p));
			}
	}
}