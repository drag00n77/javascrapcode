import java.util.Scanner;

public class Miles{

public static void main(String[ ] args)
{
//stuff needed  for trip 
double start;
double End;
double totalMiles;
double Gallonsused;
double Milespergallon;
Scanner scan= new Scanner (System.in);
//adding start and end of odometer reading
System.out.print("start of odometer reading");
start= scan.nextDouble();
System.out.println();
System.out.print("end of odometer reading");
End=scan.nextDouble();
System.out.println();

//math
System.out.println("number of gallons");
Gallonsused= scan.nextDouble();
System.out.println("");
totalMiles=End-start;
Milespergallon=(totalMiles/ Gallonsused);
System.out.println("total mpg of trip "+ Milespergallon);
scan.close();
  }
}






























