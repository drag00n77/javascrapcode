import java.util.Scanner;

//import java.util.Scanner;
public class dice {

    public static void main(String[] args) {
    	 Scanner playerinput = new Scanner(System.in) ;
    	 System.out.print("number of sides");
    	int  a= playerinput.nextInt();
    	 playerinput.close();
    	 
    	 

    while (true) {
        int dice1=(int)(Math.random()*a+1);
        int dice2=(int)(Math.random()*a+1);
        int sum = dice1 + dice2;

        System.out.println("Roll: total = " + sum); 

        if (sum==2 || sum==3 || sum==12) {
            System.out.println("Sorry with a " + sum + " You LOSE :(");
            break;
        } else if(sum==7 || sum==11 || sum>=13 ) { 
            System.out.println("Woah!!! With a " + sum + " You WIN!!!!!!!");
            break; 
        }
  }
} 
