import java.util.Random;
import java.util.Scanner;

//name of game 
public class GuessingGame{

public static final Random Random =new Random();
public static final int Max_Number = 100;

public static void main(String[ ] args) {
 int numtoFind= Random.nextInt(Max_Number)+1;
 Scanner playerinput = new Scanner(System.in) ;
 int numtries = 0,playerGuess= 0;

 while (playerGuess != numtoFind) {
	 System.out.println("Guesss an number betwwen 1 and "+ Max_Number+" or quit by pressing zero: ");
	 playerGuess=playerinput.nextInt();
	 numtries++;
	
	 if (playerGuess== 0) {
		 break;
	 }
	 
	 if(playerGuess<1 || playerGuess> Max_Number ) { 
	  System.out.println("Guess a number beetween 1 and " +  Max_Number);
	 }else if (playerGuess > numtoFind) {
		 System.out.println("mr.kendall too high! try again.");
	 }else if (playerGuess < numtoFind) {
		 System.out.println("mr.kendall too low! try again.");
     }
 }
 playerinput.close();
 if (playerGuess == numtoFind) {
 System.out.println("you won you found the number " + numtoFind + " in " + numtries + " tries!");
 }else if(playerGuess == 0) {
 		System.out.println("game over! " + "The asnwer was: " + numtoFind);
 	}
}
}