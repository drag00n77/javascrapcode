
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class StudentGrades {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Map<String, String> grades = new TreeMap<>();

        System.out.println("Student Grade Management System");
        boolean running = true;

        while (running) {
            System.out.println("\nOptions:");
            System.out.println("1. Add student");
            System.out.println("2. Remove student");
            System.out.println("3. Modify grade");
            System.out.println("4. Print all grades");
            System.out.println("5. Quit");
            System.out.print("Enter your choice (1-5): ");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter student name: ");
                    String name = input.next();
                    System.out.print("Enter student grade: ");
                    String grade = input.next();
                    grades.put(name, grade);
                    System.out.println("Student " + name + " added with grade " + grade);
                    break;
                case 2:
                    System.out.print("Enter student name to remove: ");
                    String nameToRemove = input.next();
                    String removedGrade = grades.remove(nameToRemove);
                    if (removedGrade != null) {
                        System.out.println("Student " + nameToRemove + " removed with grade " + removedGrade);
                    } else {
                        System.out.println("Student " + nameToRemove + " not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter student name to modify grade: ");
                    String nameToModify = input.next();
                    if (grades.containsKey(nameToModify)) {
                        System.out.print("Enter new grade: ");
                        String newGrade = input.next();
                        grades.put(nameToModify, newGrade);
                        System.out.println("Grade modified for student " + nameToModify);
                    } else {
                        System.out.println("Student " + nameToModify + " not found.");
                    }
                    break;
                case 4:
                    System.out.println("All Grades:");
                    for (Map.Entry<String, String> entry : grades.entrySet()) {
                        String studentName = entry.getKey();
                        String studentGrade = entry.getValue();
                        System.out.println(studentName + ": " + studentGrade);
                    }
                    break;
                case 5:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }

        System.out.println("Program exited.");
        input.close();
    }
}
