//import java.util.Scanner;

public class Player {
	private int hand;
	private int numCards;
	private boolean hasAce;
	private String playerName;
 
public Player(String name) {
	hand=0;
	numCards=0;
	hasAce=false;
	playerName=name;
  }
public void drawCard() { 
	PlayingCards card = new PlayingCards();
	numCards += 1;
	hand += card.pointVaule();
	if(card.getName().compareTo("Ace")==0) {
	hasAce= true;	
	}
	System.out.println(playerName + " got a " + card +"."  );
}
public int totalHand() {
	int total=0;
	
	if (hasAce) { 
		if (hand<=11) {
		hand=hand-1+11;
	 }
  }

 total=hand;
 return(total);
 }
 public void endHand(){
	 hand=0;
	numCards=0;
	hasAce=false;
	 
  }
 }
 