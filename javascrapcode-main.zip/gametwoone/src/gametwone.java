import java.util.Scanner;
public class gametwone
{
 
public static void main(String[] args) {

Player playerone = new Player("You");
Player computer = new Player("Computer");
Scanner input = new Scanner(System.in);
String another,keepPlaying;

do {
	playerone.drawCard();
	playerone.drawCard();
	computer.drawCard();
	computer.drawCard();
	System.out.println("do want more cards Y/N");
	another=input.nextLine();
	if(another.compareToIgnoreCase("Y")== 0 ) {
		playerone.drawCard();
	}
	
	if(computer.totalHand()< playerone.totalHand()&& playerone.totalHand()<=21 && computer.totalHand()<21) {
		computer.drawCard();
	}
	//determine winner
		if(computer.totalHand()< playerone.totalHand() && playerone.totalHand()<=21) {
			System.out.println("you win");
		}else if(computer.totalHand()> playerone.totalHand()&& computer.totalHand()<=21){
			System.out.println("computer win");
		} else if (playerone.totalHand()>21 && computer.totalHand() <=21) {
			System.out.println("computer win");
		} else if (computer.totalHand() >21 && playerone.totalHand() <=21) {
			System.out.println("you wins ");
		}else if (computer.totalHand() >21 && playerone.totalHand() >21) {
			System.out.println("you both lose");
		}else if (computer.totalHand() == playerone.totalHand() && computer.totalHand()<=21 && playerone.totalHand()<=21)  
		{ 
			System.out.println("draw");
		}

	playerone.endHand();
		computer.endHand();
		System.out.println("play another round (Y/N)"); 
		keepPlaying = input.nextLine(); 
        }
        while (keepPlaying.compareToIgnoreCase("Y")==0 ); 
 input.close();
}

}


		
			
