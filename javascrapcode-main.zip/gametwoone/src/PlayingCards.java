import java.lang.Math;

public class PlayingCards {
	private int card;
	public  PlayingCards() {
		card=(int)(13*Math.random()+1);
	}
	public int pointVaule() { 
		int points=0;
		switch(card) {
		case 1: points=1; break;
		case 2: points=2; break;
		case 3: points=3; break;
		case 4: points=4; break;
		case 5: points=5; break; 
		case 6: points=6; break; 
		case 7: points=7; break;
		case 8: points=8; break; 
		case 9: points=9; break;
		case 10:
		case 11:
		case 12:
		case 13:points=10;break;
		
		}
		return(points);
	}
	public String getName() {
		String face="";
		switch(card) {
		case 1: face="ace"; break;
		case 2: face="two"; break;
		case 3: face="three"; break;
		case 4: face="four"; break;
		case 5: face="five"; break;
		case 6: face="six"; break;
		case 7: face="seven"; break;
		case 8: face="eight"; break;
		case 9: face="nine"; break;
		case 10:face="ten"; break;
		case 11:face="jack"; break;
		case 12:face="queen"; break;
		case 13:face="king "; break;
	}
		return(face);
}
	public String toString() {
		return(getName());
	}
}