import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class sorry {
	public static void main(String args[]) {
		  System.out.println();
		System.out.println(" goal of sorry: is go around the board,and get back to home.");
	    System.out.println();
	    System.out.println(" your four pieces will get around board by picking out cards from the deck ");
	    System.out.println();
	    System.out.println("if you or opponents get the sorry card you move one of your piece from the start or anywhere and eat the opponents piece unless their on final strench or on safe spot ");
	    System.out.print( " you can also eat the opponent piece if you land on the space/block after opponent, you can't eat opponent piece on a safe space " );//
	    System.out.println();
	    Scanner one = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("");
	    System.out.println("pick A color for playerOne from(red,yelow,green,and blue) or make your own names  ");

	    String playerOne = one.nextLine();
	    //
	    Scanner two = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("pick A color for playerTwo from(red,yelow,green,and blue) or make your own names ");

	    String playerTwo = two.nextLine();
	    //
	    Scanner three = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("pick A color for playerThree from(red,yelow,green,and blue) or make your own names ");
	    
	    String playerThree = three.nextLine();
	    //
	    Scanner four = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("pick A color for playerFour from(red,yelow,green,and blue) or make your own names ");

	    String playerFour = four.nextLine();
	    ArrayList<String> cards = new ArrayList<String>();
	    cards.add("1"); cards.add("2"); cards.add("3"); cards.add("4"); cards.add("5"); cards.add("6"); cards.add("7"); cards.add("8");cards.add("9");cards.add("10");cards.add("11");cards.add("12"); cards.add("sorry");
	   
	    
	  //  System.out.println("First element of the array list: "+cards.get(0));
	    ArrayList<String> card = new ArrayList<String>();
	    //you need to get one or 6 
	    //i=player1 t=player2 j=player3 z=player4 
	    int i= (int)(Math.random()*cards.size());
	    int t= (int)(Math.random()*cards.size());
	    int j= (int)(Math.random()*cards.size());
	    int z= (int)(Math.random()*cards.size());
	    //randomnum * lenght of array -> 0-lenght -> index
	    card.add(cards.get(i));
	    System.out.println("pick a card get one,and six to get out or get sorry and get out if there is an opponents piece on the board, player "+playerOne );
	    System.out.println("First card is : "+cards.get(i));
	    
	    System.out.println("pick a card get one,and six to get out or get sorry and get out if there is an opponents piece on the board, player "+playerTwo );
	    System.out.println("Second card is : "+cards.get(t));
	    
	    System.out.println("pick a card get one,and six to get out or get sorry and get out if there is an opponents piece on the board, player "+playerThree );
	    System.out.println("thrid card is : "+cards.get(j));
	    
	    System.out.println("pick a card get one,and six to get out or get sorry and get out if there is an opponents piece on the board, player "+playerFour );
	    System.out.println("fourth card is : "+cards.get(z));
	    
	    //player one 
	    switch(cards.get(i)) {
	    case "1":
	      // you can go again after moving 1 for any of your pieces on the board or take out piece from base 
	    	 System.out.println(playerOne +": "+cards.get(i));
	      break;
	    case "6":
	      // you can go again after moving 6 for any of your pieces on the board or take out piece from base 
	      break;
	    default:
	      // you can't go again and it other players turn.
	    	
	    	
	    	//player two
	    	switch(cards.get(t)) {
		    case "1":
		      // you can go again after moving 1 for any of your pieces on the board or take out piece from base  
		      break;
		    case "6":
		      // you can go again after moving 6 for any of your pieces on the board or take out piece from base 
		      break;
		    default:
		      // you can't go again and it other players turn.
		    	
		    	
		    //player three
		    	switch(cards.get(j)) {
			    case "1":
			      // you can go again after moving 1 for any of your pieces on the board or take out piece from base  
			      break;
			    case "6":
			      // you can go again after moving 6 for any of your pieces on the board or take out piece from base 
			      break;
			    default:
			      // you can't go again and it other players turn.
			    	
			    	//player four
			    	switch(cards.get(z)) {
				    case "1":
				      // you can go again after moving 1 for any of your pieces on the board or take out piece from base  
				    	
				      break;
				    case "6":
				      // you can go again after moving 6 for any of your pieces on the board or take out piece from base 
				      break;
				    default:
				      // you can't go again and it other players turn.
		    
		    	
}
}
}
}
}  
}
