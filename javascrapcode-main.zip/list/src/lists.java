import java.util.Scanner;
public class lists
{
	public static void main(String[] args) {		
Scanner scan = new Scanner(System.in);
System.out. println("Please enter a number 1 - 100 and enter 101 to terminate : ");
int thisCheck = scan.nextInt();
int[] counterArray = new int[10];
while (thisCheck != 101) {		

if (thisCheck < 10 && thisCheck>0) {
counterArray[0]+=1 ;
}
else if (thisCheck < 20) {
counterArray[1] += 1;
}
else if (thisCheck < 30) {
counterArray[2] += 1;
 }
else if (thisCheck < 40) {
counterArray[3] += 1;
 }
else if (thisCheck < 50) {
counterArray[4] += 1;
 }
else if (thisCheck < 60) {
counterArray[5] += 1;
 }
else if (thisCheck < 70) {
counterArray[6] += 1;
 }
else if (thisCheck < 80) {
counterArray[7] += 1;
 }
else if (thisCheck < 90) {
counterArray[8] += 1;
 }
else if (thisCheck <= 100) {
counterArray[9] += 1;
 }
//printer
for (int i = 0; i < 10; i++) {
	  System.out.format("%2d-%3d ", i*10+1, i*10+10);
	  for (int j = 0; j < counterArray[i]; j++)
	    System.out.print("*");
	  System.out.println();
}

System.out. println("Please enter a number 1 - 100 and pick 101 to print : ");
thisCheck = scan.nextInt();
}

System.out.println("This is the final array that represents the list.");
for (int i = 0; i < 10; i++) {
	  System.out.format("%2d-%3d ", i*10+1, i*10+10);
	  for (int j = 0; j < counterArray[i]; j++)
	    System.out.print("*");
	  System.out.println();
	
	}
System.out.println("Program has terminated using user input.");
scan.close();
}
}

