//import java.util.HashSet;
//import java.util.Random;
import java.util.Scanner;

public class combo
{
	  

    public combo()
    {
        openStatus = false;
        count = 0;
        combination1 = ' '; //first letter
        combination2 = ' '; //second letter
        combination3 = ' ';//3rd letter
        position1 = ' ';
        position2 = ' ';
        position3 = ' ';
       
          
    }
    
    public cobmo(String a)
    {/Scanner myObj = new Scanner(System.in);

    System.out.println("Enter combo :");
    	
    String a = myObj.nextLine();
        myObj.close();
    	
    	
        openStatus = false;
        count = 0;
        
        if (a.length() == 3)
        { //abc
            combination1 = a.charAt(0);
            combination2 =a.charAt(0);
            combination3 =a.charAt(0);
        }
        else
            System.out.println("Invalid combination!");
        position1 = ' ';
        position2 = ' ';
        position3 = ' ';
    }
     
    public void setPosition(String positionI)
    {
        char position = positionI.charAt(0);
        count++;
        if (count >= 4)
        {
            position1 = position2;
            position2 = position3;
            position3 = position;
        }
        if (count == 1)
            position1 = position;
        else if (count == 2)
            position2 = position;
        else if (count == 3)
            position3 = position;
        else
            System.out.println("Error.");
    }
     
    public void unlock()
    {
        if (position1 == combination1 && position2 == combination2 && position3 == combination3)
            openStatus = true;
        else
            openStatus = false;
            System.out.println("Wrong combination!");
    }
     
    public boolean isOpen()
    {
        return openStatus;
    }
     
    public void lock()
    {
        count = 0;
        openStatus = false;
    }
  
    private boolean openStatus;
  
    private int count;
  
    private char combination1;
    private char combination2;
    private char combination3;
     
    private char position1;
    private char position2;
    private char position3;

  
}




/*public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);

    System.out.println("Enter combo :");

    // String input
    String combinationI = myObj.nextLine();
    myObj.close();
}


/* HashSet<String> p = new HashSet<String>();
p.add("a");  p.add("b");
p.add("c");  p.add("d");
 p.add("e"); p.add("f");
 p.add("g"); p.add("h");
 p.add("i"); p.add("j");
 p.add("k"); p.add("l");
 p.add("m"); p.add("n");
 p.add("o"); p.add("p");  
 p.add("q"); p.add("r"); 
 p.add("s"); p.add("t");
 p.add("u");  p.add("v");
 p.add("w"); p.add("x");
 p.add("y");  p.add("z");
 int size = p.size();
 int item = new Random().nextInt(size); // In real life, the Random object should be rather more shared than this
 int i = 0;
 for(Object obj : p)
 {
     if (i == item)
         return ;
     i++;
 }

return ;
public class cobmo{
public static void main(String[] args) { 
	   Scanner combinationI = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("Enter combo");

	    String combo = combinationI.nextLine();
	
}

}
*/	