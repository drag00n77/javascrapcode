import java.util.Scanner;

public class CombinationLock
{
    public CombinationLock()
    {
        openStatus = false;
        count = 0;
        combination1 = ' ';
        combination2 = ' ';
        combination3 = ' ';
        position1 = ' ';
        position2 = ' ';
        position3 = ' ';
          
    }
     
    public CombinationLock(String combinationI)
    {
        openStatus = false;
        count = 0;
        
        if (combinationI.length() == 3)
        {
            combination1 = combinationI.charAt(0);
            combination2 = combinationI.charAt(1);
            combination3 = combinationI.charAt(2);
        }
        else
            System.out.println("Invalid combination!");
        position1 = ' ';
        position2 = ' ';
        position3 = ' ';
    }
     
    public void setPosition(String positionI)
    {
        char position = positionI.charAt(0);
        count++;
        if (count >= 4)
        {
            position1 = position2;
            position2 = position3;
            position3 = position;
        }
        if (count == 1)
            position1 = position;
        else if (count == 2)
            position2 = position;
        else if (count == 3)
            position3 = position;
        else
            System.out.println("Error.");
    }
     
    public void unlock()
    {
        if (position1 == combination1 && position2 == combination2 && position3 == combination3)
            openStatus = true;
        else
            openStatus = false;
            System.out.println("Wrong combination!");
    }
     
    public boolean isOpen()
    {
        return openStatus;
    }
     
    public void lock()
    {
        count = 0;
        openStatus = false;
    }
  
    private boolean openStatus;
  
    private int count;
  
    private char combination1;
    private char combination2;
    private char combination3;
     
    private char position1;
    private char position2;
    private char position3;
}