import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class AppointmentBook {
    private ArrayList<Appointment> appointments;

    public AppointmentBook() {
        this.appointments = new ArrayList<>();
    }

    public void addAppointment(Appointment newAppointment) {
        int index = Collections.binarySearch(appointments, newAppointment);
        if (index < 0) {
            index = -index - 1;
            if (isValidAppointment(index, newAppointment)) {
                appointments.add(index, newAppointment);
            } else {
                System.out.println("Cannot add appointment. There is a conflict with another appointment.");
            }
        } else {
            System.out.println("Cannot add appointment. There is a conflict with another appointment.");
        }
    }

    public void printAppointmentsForDay(LocalDate day) {
        System.out.println("Appointments for " + day.toString() + ":");
        for (Appointment appointment : appointments) {
            if (appointment.getDate().equals(day)) {
                System.out.println(appointment.toString());
               
                }

            }
        }
    

    private boolean isValidAppointment(int index, Appointment newAppointment) {
        if (index > 0) {
            Appointment previousAppointment = appointments.get(index - 1);
            if (newAppointment.getDate().equals(previousAppointment.getDate())) {
                if (newAppointment.getStartTime().compareTo(previousAppointment.getEndTime()) < 0) {
                    return false;
                }
            }
        }
        if (index < appointments.size()) {
            Appointment nextAppointment = appointments.get(index);
            if (newAppointment.getDate().equals(nextAppointment.getDate())) {
                if (newAppointment.getEndTime().compareTo(nextAppointment.getStartTime()) > 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        AppointmentBook appointmentBook = new AppointmentBook();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Enter event in book (add, print, quit):");
            String command = scanner.nextLine();
            if (command.equals("add")) {
                System.out.println("Enter appointment description:");
                String description = scanner.nextLine();
                System.out.println("Enter appointment date (yyyy-mm-dd): example 2018-09-07");
                LocalDate date = LocalDate.parse(scanner.nextLine());
                System.out.println("Enter appointment start time (hh:mm): example 02:10");
                LocalTime startTime = LocalTime.parse(scanner.nextLine());
                System.out.println("Enter appointment end time (hh:mm): example 01:01");
                LocalTime endTime = LocalTime.parse(scanner.nextLine());
                Appointment newAppointment = new Appointment(description, date, startTime, endTime);
                appointmentBook.addAppointment(newAppointment);
            } else if (command.equals("print")) {
                System.out.println("Enter date to print appointments for (yyyy-mm-dd): example  2018-09-07");
                LocalDate date = LocalDate.parse(scanner.nextLine());
                appointmentBook.printAppointmentsForDay(date);
            } else if (command.equals("quit")) {
                break;
            } else {
                System.out.println("Invalid command.");
            }
            
        }
        scanner.close();
       
    	}

    }

