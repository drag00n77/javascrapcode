import java.time.LocalDate;
import java.time.LocalTime;

public class Appointment implements Comparable<Appointment> {
    private String description;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;

    public Appointment(String description, LocalDate date, LocalTime startTime, LocalTime endTime) {
        this.description = description;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getDescription() {
        return description;
    } @Override
    public String toString() {
        return "Appointment: " + description + " on " + date.toString() + " from " + startTime.toString() + " to " + endTime.toString();}

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

	@Override
	public int compareTo(Appointment o) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
