
import java.util.Scanner;


public class Spend{
public static void main(String[]args) {
	Scanner input = new Scanner (System.in);
		System.out.print("rent:");
 float b=(float) input.nextFloat();
	 	System.out.print("food:");
 float a=(float) input.nextFloat();
	  	System.out.print("entertainment:");
 float c=(float) input.nextFloat();
	  	System.out.print("clothing :");
	 float d=(float) input.nextFloat();
	 input.close();
	 float total = a+b+c+d;
	 float food = a/total;
	 float rent = b/total;
	 float fun = c/total;
	 float clothing = d/total;
	 float p = 100;
	
	 System.out.println( );
	 System.out.println("cost of living per month" );
	 
	 System.out.println("rent: $"+ b );
	 System.out.println("food: $"+ a );
	 System.out.println("entertainment: $"+ c );
	 System.out.println("clothing: $"+ d );
	 System.out.println( );
	 
	 System.out.println("category   " +" budget");
	 System.out.println("rent          "+rent*p+"%");
	 System.out.println("food          "+food*p+"%");
	 System.out.println("entertainment "+fun*p+"%");
	 System.out.println("clothing      "+clothing*p+"%");
	 
   }
}
