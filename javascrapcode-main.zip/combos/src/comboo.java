import java.util.Scanner;

public class  comboo {
	 public static void main(String[] args)
	    { Scanner myObj = new Scanner(System.in);

	    System.out.println("Enter combo in letters :");
	    String aaa = myObj.nextLine();
	        myObj.close();
	        comboo combination = new comboo(aaa);
	       
	    }
    
    	public comboo (String aaa) {
    			
        openStatus = false;
        count = 0;
        
        if (aaa.length() == 3)
        { //bac
            combination1 = aaa.charAt(0);
            combination2 =aaa.charAt(1);
            combination3 =aaa.charAt(2);
        }
        
        else  {
            System.out.println("Invalid combination!");
          
        position1 = ' ';
        position2 = ' ';
        position3 = ' ';
        
        
        }
        
        setPosition(aaa);
        
    }  
     
    public void setPosition(String positionI)
    {
        char position = positionI.charAt(0);

        //System.out.println("b");
        count++;
        if (count >= 4)
        {
            position1 = position2;
            position2 = position3;
            position3 = position;
        }
        if (count == 1)
            position1 = position;
       else if (count == 2)
          position2 = position;
        else if (count == 3)
           position3 = position;
       
        else
            System.out.println("Error.");
        unlock();
       
    }
   

     
    public void unlock()
    {
    	//System.out.println(combination1 );
    	//System.out.println("c");
        //System.out.println(position3 + " equals " + combination3);
    	if ('a' == combination1 && 'a' == combination2 && 'c' == combination3)
            {openStatus = true;
            System.out.println("right combination!");
            }
        else  {
            openStatus = false;
            System.out.println("Wrong combination!");
    	}
    }
   
    	
    
     
    public boolean isOpen()
    {
        return openStatus;
    }
     
    public void lock()
    {
        count = 0;
        openStatus = false;
    }
  
    private boolean openStatus;
  
    private int count;
  
    private char combination1;
    private char combination2;
    private char combination3;
     
    private char position1;
    private char position2;
    private char position3;



	   
     /* count = 0;
      combination1 = ' '; //first letter
      combination2 = ' '; //second letter
      combination3 = ' ';//3rd letter
      position1 = ' ';
      position2 = ' ';
      position3 = ' ';
       openStatus = true;
      */
}
     
