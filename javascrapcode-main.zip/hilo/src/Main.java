import java.util.Currency;
import java.util.Scanner;
import java.text.NumberFormat;
import java.util.Locale;

public class Main {
	
	public static String addCoins(int quarter,int dime,int nickel,int penny) {
	  String value;
	  double  total;
	  double totals;
	  Scanner input = new Scanner (System.in);
		 System.out.println("Enter your total coins ");
		 
		 	System.out.print("Quarters: " );
		 	quarter = input.nextInt();
		    
		 	System.out.print("Dimes: ");
		 	dime = input.nextInt();
		    
		   	System.out.print("Nickels: ");
		   	nickel = input.nextInt();
		    
		   	System.out.print("Pennies: ");
		    penny = input.nextInt();
		    input.close();
	  
		    totals=(quarter*.25 + dime*.10 + nickel*0.05 + penny*.01);
		    total=(double) Math.round(totals*100)/100;
		    
		    NumberFormat nF = NumberFormat.getInstance();
		    nF.setCurrency(
		            Currency.getInstance(
		                Locale.US));
		  value  = nF.getCurrency().getDisplayName();
		  
		    
		   value=("$"+total);
		   return (value);
  }
	 public static void main(String[] args) {
		 
		System.out.print("total "+ addCoins(0, 0, 0, 0));
  }
}