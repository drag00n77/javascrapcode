
 class Truck extends Vehicle{
	
	 public Truck() {
		 int seats=2;
		 int wheels =6;
		 int mpg =20;
		 String carType="truck";
	 } 
		 void moreinfo() {super.info();
		 System.out.println("truck "+" have "+ wheels+" " + seats+" "+" Miles per gallon");
	 }
 
 }
 
 
