import java.util.Scanner;
public class driver {
		
public static void main(String[] args)
{
	System.out.println("what vehicle would like learn about?");
	Scanner input = new Scanner(System.in);
	System.out.println("Car or Minivan or Truck");
	String vehicleType = input.nextLine();
	if (vehicleType.equals("Car")) { Car c=new Car();
		c.moreinfo();
	}else if  (vehicleType.equals("Truck")) { Truck c=new Truck();
	c.moreinfo();
	}else if (vehicleType.equals("Minivan")) { Minivan c=new Minivan();
	c.moreinfo();
	
	
}
}
}
