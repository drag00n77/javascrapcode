
abstract class Vehicle {
	String steeringwheel="all vehicles have one steering wheel";
	String move ="all vehicles have move forward and backwards";
	String turn ="all vehicles turn left and right";
	void info() {System.out.println(steeringwheel+" "+move+" "+turn+" ");}
	
	public double weight;
	public double mpg;
	public int seats;
	public int wheels ;
	//methods
	
	
	
	
	//get setter
	public double getWeight() {
		return weight;
	}
	public void getWeight(double weight) {
		this.weight=weight;
	}
	public int getMpg() {
		return (int) mpg;
	}
	public void getMpg(int mpg) {
		this.mpg=mpg;
	}
	public int  getSeats() {
		return seats;
	}
	public void getBrand(int seats) {
		this.seats=seats;
	}
	
	
	
	
	
	//get setter
} 
	   
	