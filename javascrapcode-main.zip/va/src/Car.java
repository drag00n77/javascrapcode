 public class Car extends Vehicle{
	String wheels = "Four";
	public Car() {
	super();
	int wheel=4;
	int seats=4;
	int mpg=50;
	}
	 void moreinfo() {super.info();
	 System.out.println("car "+" have "+ wheels+" " + seats+" "+" Miles per gallon");
 }
}
 