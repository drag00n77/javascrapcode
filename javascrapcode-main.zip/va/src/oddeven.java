
	import java.util.ArrayList;

	public class oddeven {
	  public static void main(String[] args) {
		  int min = 0;  
		  int max = 99;  
	    int  num = (int)(Math.random()*(max-min+1)+min);
	  ArrayList<Integer> even = new ArrayList<Integer>();
	  ArrayList<Integer> odd = new ArrayList<Integer>();
		for(int i=0;i<25;i++) {
			 num = (int)(Math.random()*(max-min+1)+min);
	 if ( num%2==0) {
		 
	 	even.add(num);
	 } else  {
		 
			odd.add(num);
				      
		}
		}
		  System.out.println("even "+even);	   
		  System.out.println("odd"+ odd);	
		}	

		}



		 
