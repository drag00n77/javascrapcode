
public class Minivan extends Vehicle {
	String wheels="Four";
	public Minivan() {
		int wheels=4;
		int mpg=30;
		int seats=7;
	}
		 void moreinfo() {
			 super.info();
		 System.out.println("truck"+" have "+ wheels+" " + seats+" "+" Miles per gallon");
 }
}

