package Numbers;

import java.util.Scanner;
import java.lang.String;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		String in = sc.nextLine();
		sc.close();
		
		char[] rnum = in.toLowerCase().toCharArray();
		for (char x: rnum)
			System.out.print(x);
	}

	private static int poop (char c) {
		if(c== 'm')
			return 0;
		else if(c=='d')
			return 1;
		else if(c=='c')
			return 2;
		else if(c=='l')
			return 3;
		else if(c=='x')
			return 4;
		else if(c=='v')
			return 5;
		else if(c=='i')
			return 6;
		}
	}
}