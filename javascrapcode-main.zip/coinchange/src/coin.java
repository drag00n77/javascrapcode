import java.util.Scanner;
public class coin {
 
 public static void main(String args[]) {
  
   Scanner input = new Scanner (System.in);
   int quarter;
   int dime;
   int nickel;
   int penny;
   int coins;
  
   System.out.print("Enter the change in cents: ");
   coins = input.nextInt();
   input.close();
   quarter = coins/25;
   dime = ((coins % 25)/10);
   nickel = (((coins % 25)%10)/5);
   penny = ((((coins % 25) % 10)%5)/1);  
   System.out.println("The minimum number of coins is:");
   System.out.println("Quarters: " + quarter);
   System.out.println("Dimes: " + dime);
   System.out.println("Nickels: " + nickel);
   System.out.println("Pennies: " + penny);
   
 }
}