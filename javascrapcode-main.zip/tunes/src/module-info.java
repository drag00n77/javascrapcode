public class RockPaperScissors{
	public static void main (String[]args) {
		final int choices = 3;
		final int ROCK = 1, PAPER = 2, SCISSORS = 3;
		final int COMPUTER = 1, PLAYER = 2, TIE = 3;
		int computer, player, winner = 0;
		int wins = 0, losses = 0, ties = 0;