import javax.swing.*;
public class guisum{

public static void main(String[]args) {
	String sum1,sum2 ;
	

	Integer one;
	Integer two;
	Integer total;
	Integer sum;
	String another = "y";
	
		while(another.equalsIgnoreCase("y")) {
			sum1 =JOptionPane.showInputDialog("Enter a integer:");
			sum2 =JOptionPane.showInputDialog("Enter a integer:");
			one=Integer.parseInt(sum1);
			two=Integer.parseInt(sum2);
		 total=	one + two;
		 sum= one * two;
		 JOptionPane.showMessageDialog(null,"the total is: "+total);
		 JOptionPane.showMessageDialog(null,"the sum is: "+sum);
		 another=JOptionPane.showInputDialog("Try again (y/n)? ");
		 if (another=="n") {
			 break;
			}
			
			
			
	}
}
}
