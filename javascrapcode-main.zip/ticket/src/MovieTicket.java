//Design and implement an application that simulates the customers
//waiting in line to buy movie tickets. Use a queue. As customers
//arrive at the theater, customer objects are put in the rear of the
//queue with an enqueue operation. When the ticket seller is ready
//for another customer, the customer object is removed from the
//front of the queue with a dequeue operation. Randomly determine
//when new customers arrive at the theater and when current customers are finished at the ticket window. Print a message each
//time an operation occurs during the simulation. Write your own
//queue data structure

import java.util.Random;

public class MovieTicket {
	private Random generator;
	private int customerCount;
	private Line line;
	private final int MAX_Num_CUSTOMERS=5; 
	private final int MAX_CUST_SERVICED=4;
	public MovieTicket()
	{ 
		generator=new Random();
		customerCount=0;
		line=new Line();
	}
	public void run(int cycles)
	{
		int numCust,custServiced;
		Customer person;
		for(int i=0; i<cycles; i++)
		{
			numCust= generator.nextInt(MAX_Num_CUSTOMERS);
			for(int j=0; j<numCust; j++)
			{ person = new Customer(customerCount++);
			line.addCustomer(person);
			System.out.println(person + " joins ticket line" );
			}
			custServiced =generator.nextInt(MAX_CUST_SERVICED);
			for(int j=0; j<custServiced; j++ )
			{
				if(line.isEmpty())
					System.out.println(" is waiting");
				else
				{
					System.out.println(line.nextCustomer()+" is getting tickets");
				}
			}
		}
		System.out.println(" last chance to buy tickets, Ticket counter is closing... ");
		while(!line.isEmpty())
			System.out.println(line.nextCustomer()+" is getting tickets");
	}
	public static void main(String args[])
	{
		new MovieTicket().run(10);
	}
}