import java.util.LinkedList;
import java.util.Queue;
public class Line {
	Queue<Customer>queue;
	public Line() 
	{
		queue = new LinkedList<Customer>();
	}
	public Customer nextCustomer() {
		return queue.remove();
		
	}
	public void addCustomer(Customer person) 
	{
		queue.add(person);
	}
	public boolean isEmpty()
	{
		return queue.isEmpty();
	}
	public int size() {
		return queue.size();
	}
}
