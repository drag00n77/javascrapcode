
public class Customer {
	int id;
public Customer(int number)
{
	id=number;
}
public String toString() {
	return "Customer "+ id;
}
}
