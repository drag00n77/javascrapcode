import java.util.Scanner;
import java.lang.String;

public class romannms{
	public static void main (String args[]) {
		Scanner sc = new Scanner (System.in);
		char[] in = sc.nextLine().toLowerCase().toCharArray();
		sc.close();
		for (char c:in)
			System.out.println(c);

	}
}