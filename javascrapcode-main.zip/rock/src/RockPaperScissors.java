
		import java.util.Random;
		import java.util.Scanner;
		 
		public class RockPaperScissors {
		 
		public static final String ROCK = "R";
		public static final String PAPER = "P";
		public static final String SCISSORS = "S";
		
		public static void getResult(String usersMove, String computersMove) {
		        System.out.println("Computer's move is: " + computersMove);
		        
		 //computer
		        
		       
		    
		        public static String getComputersMove(){
		        int computersNum;
		        String computersMove="";
		        Random random = new Random();
		        computersNum = random.nextInt(3) + 1;
		        if (computersNum == 1)
		        computersMove = ROCK;
		        else if (computersNum == 2)
		        computersMove = PAPER;
		        else if (computersNum == 3)
		        computersMove = SCISSORS;
		        return computersMove;
		        }
		        /**
		        * user input
		        * */
		        public static String getUsersMove(){
		            Scanner playerinput = new Scanner(System.in);
		            System.out.println("Enter your move: ");
		            String input = playerinput.next().toUpperCase();
		        playerinput.close();
		                return input;
		               
		               
		            }
		            
		             // how to play the game
		            
		        public static void main(String[] args) {
		        System.out.println( "Rock, Paper, Scissors shoot!\n"
		        + "Please enter your move.\n"
		        +"Rock is R, Paper is  P, and Scissors is S.\n");
		        String userInput = getUsersMove();
		        while (userInput.equals(PAPER) || userInput.equals(ROCK) || userInput.equals(SCISSORS))
		        getResult(userInput, getComputersMove());
		        
		    
		        }
		        }
		        
		       