import java.util.Scanner;

public class  WordScrambler {
public static void main(String[]args) {
	Scanner in = new Scanner(System.in);
	char[]letter;
	String word;
	
 
     System.out.println("enter string");
    	 word = in.nextLine();
    	letter = word.toCharArray();
    	
    	for(int i=0;i< letter.length;i++) {
    		if((letter[i]>= 'A'&& letter[i]<='Z')||(letter[i]>='a'&&letter[i]<='z')){
    			if(letter[i]=='y') {
    				letter[i]='a';
    			}else if(letter[i]=='Y') {
    				letter[i]='A';
    			}else if(letter[i]=='z') {
    				letter[i]='b';
    		}else if(letter[i]=='Z') {
				letter[i]='B';
    		}else {
    			letter[i]=(char)(letter[i]+2);
    		 }
    		}
    			
    		
    	
    System.out.print(letter[i]);	
    	
	
}
}
}
