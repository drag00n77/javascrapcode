// Subclass (inherit from Animal)
class Pig extends  Animal {
  public void animalSound() {
    // The body of animalSound() is provided here
    System.out.println("The pig says: wee wee");
  }
}
