import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SorryGames {
    public static void main(String args[]) {
        System.out.println("Goal of Sorry: Go around the board and get back to home.");
        System.out.println("Your four pieces will move around the board by picking cards from the deck.");
        System.out.println("If you or your opponents get the sorry card, you can move one of your pieces from the start or anywhere and send the opponent's piece back to their start unless they are on the final stretch or a safe spot.");
        System.out.println("You can also send opponent's piece back if you land on the space/block after the opponent, but you can't do it on a safe space.");

        Scanner scanner = new Scanner(System.in);

        System.out.println("\nPick a color for playerOne (red, yellow, green, or blue) or enter a custom name: ");
        String playerOne = scanner.nextLine();

        System.out.println("Pick a color for playerTwo (red, yellow, green, or blue) or enter a custom name: ");
        String playerTwo = scanner.nextLine();

        System.out.println("Pick a color for playerThree (red, yellow, green, or blue) or enter a custom name: ");
        String playerThree = scanner.nextLine();

        System.out.println("Pick a color for playerFour (red, yellow, green, or blue) or enter a custom name: ");
        String playerFour = scanner.nextLine();

        ArrayList<String> cards = new ArrayList<String>();
        cards.add("1");
        cards.add("2");
        cards.add("3");
        cards.add("4");
        cards.add("5");
        cards.add("6");
        cards.add("sorry");

        ArrayList<String> card = new ArrayList<String>();

        // Roll the dice until someone gets a 6 or 1
        int roll = 0;
        while (!(roll == 6 || roll == 1)) {
            roll = (int) (Math.random() * cards.size());
        }

        card.add(cards.get(roll));

        System.out.println("Player One: " + playerOne);
        System.out.println("First card is: " + cards.get(roll));

        // Roll the dice until someone gets a 6 or 1
        roll = 0;
        while (!(roll == 6 || roll == 1)) {
            roll = (int) (Math.random() * cards.size());
        }

        card.add(cards.get(roll));

        System.out.println("Player Two: " + playerTwo);
        System.out.println("Second card is: " + cards.get(roll));

        // Roll the dice until someone gets a 6 or 1
        roll = 0;
        while (!(roll == 6 || roll == 1)) {
            roll = (int) (Math.random() * cards.size());
        }

        card.add(cards.get(roll));

        System.out.println("Player Three: " + playerThree);
        System.out.println("Third card is: " + cards.get(roll));

        // Roll the dice until someone gets a 6 or 1
        roll = 0;
        while (!(roll == 6 || roll == 1)) {
            roll = (int) (Math.random() * cards.size());
        }

        card.add(cards.get(roll));

        System.out.println("Player Four: " + playerFour);
        System.out.println("Fourth card is: " + cards.get(roll));

        // Rest of the game logic goes here
    }
}
