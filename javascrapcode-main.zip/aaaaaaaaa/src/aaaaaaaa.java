//public class aaaaaaaa
//{  
//public static void main( String args[] )   
//{  
//int min = 0;  
//int max = 6;  
  
//System.out.println("Random value between "+min+" to "+max+ ":");  
//System.out.println((int) (Math.random()*(max-min+1)+min));   
//}
//}