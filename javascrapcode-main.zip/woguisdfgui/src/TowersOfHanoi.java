import java.util.Scanner;

//Online Java Compiler
//Use this editor to write, compile and run your Java code online
import java.util.Scanner;
public class TowersOfHanoi {
 public static void main(String[] args) {
     Scanner myObj = new Scanner(System.in);  // Create a Scanner object
 System.out.println("guess what number beetween 1-12 this program will produce");
 ;
  int a = (int)( Math.random() * (12 - 1 + 1) + 1 );
		 // System.out.println("a");
  if( a == myObj.nextInt() ){
      System.out.println("you got it right");
  }
  else {
      System.out.println("you got it wrong"+" it was "+ a );
  }
    
 }
}




/**public class TowersOfHanoi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of disks: ");
        System.out.print(" it is preferable do 5 or less");
        int n = scanner.nextInt();
        scanner.close();
        towersOfHanoi(n, 'A', 'C', 'B');
    }

    public static void towersOfHanoi(int n, char source, char target, char a) {
        if (n == 1) {
            System.out.println("Move disk 1 from " + source + " to " + target);
            return;
        }
        towersOfHanoi(n-1, source, a, target);
        System.out.println("Move disk " + n + " from " + source + " to " + target);
        towersOfHanoi(n-1, a, target, source);
    }
}
**/