
public class all {

}
