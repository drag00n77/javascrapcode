import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class poker {
    public static void main (String [] args) {  
    System.out.println(" goal: try to get the most points ");
    System.out.println();
    System.out.println("you have 20 rerolls ");
    System.out.println();
    System.out.println("royal flush is 250 points,stright flush is 50 points,four of kind is 25 points, full house is 6 points, flush is 5 points,");
    System.out.print( " stright is 4 points, three of kind is 3 points, two pair is 2 points, pair of jacks or better is  1 point" );//
    System.out.println();
   ArrayList<String> ranks = new ArrayList<String>();
   ranks.add("Ace Hearts");   ranks.add("Ace Clubs"); ranks.add("Ace Spades");  ranks.add("Ace Diamonds");
   ranks.add("2 Hearts");     ranks.add("2 Clubs");   ranks.add("2 Spades");    ranks.add("2 Diamonds");
   ranks.add("3 Hearts");     ranks.add("3 Clubs");   ranks.add("3 Spades");    ranks.add("3 Diamonds");
   ranks.add("4 Hearts");     ranks.add("4 Clubs");   ranks.add("4 Spades");    ranks.add("4 Diamonds");
   ranks.add("5 Hearts");     ranks.add("5 Clubs");   ranks.add("5 Spades");    ranks.add("5 Diamonds");
   ranks.add("6 Hearts");     ranks.add("6 Clubs");   ranks.add("6 Spades");    ranks.add("6 Diamonds");
   ranks.add("7 Hearts");     ranks.add("7 Clubs");   ranks.add("7 Spades");    ranks.add("7 Diamonds");
   ranks.add("8 Hearts");     ranks.add("8 Clubs");   ranks.add("8 Spades");    ranks.add("8 Diamonds");
   ranks.add("9 Hearts");     ranks.add("9 Clubs");   ranks.add("9 Spades");    ranks.add("9 Diamonds");
   ranks.add("10 Hearts");    ranks.add("10 Clubs");  ranks.add("10 Spades");   ranks.add("10 Diamonds");
  
   ranks.add("jack of Hearts");  ranks.add("jack of Clubs ");ranks.add("jack of Spades"); ranks.add("jack of Diamonds");
   ranks.add("queen of Hearts"); ranks.add("queen of Clubs "); ranks.add("queen of Spades "); ranks.add("queen of Diamonds");
   ranks.add("king of Hearts");  ranks.add("king of Clubs");  ranks.add("king of Spades");  ranks.add("king of Diamonds");
    
    Collections.shuffle(ranks);
   
    System.out.println("First element of the array list: "+ranks.get(0));
    System.out.println("");
    System.out.println("second element of the array list: "+ranks.get(1));
    System.out.println("");
    System.out.println("third  element of the array list: "+ranks.get(2));
    System.out.println("");
    System.out.println("Forth element of the array list: "+ranks.get(3));
    System.out.println("");
    System.out.println("Fifth element of the array list: "+ranks.get(4));
   
    for(int a=0; a<20; a++) {
    System.out.println(" reject: none or one  or all  ");
    Scanner scanner = new Scanner(System.in);
    String choice = scanner.nextLine();
    
    if (choice.equals("one")) {
    	System.out.println("pick which cards to discard by card num(1-5)");
    	Scanner sc = new Scanner(System.in);
        int remove = scanner.nextInt();
        switch(remove){      
        case 1: ranks.remove(0);  
        System.out.println("First element of the array list: "+ranks.get(0));
        System.out.println("");
        System.out.println("second element of the array list: "+ranks.get(1));
        System.out.println("");
        System.out.println("third  element of the array list: "+ranks.get(2));
        System.out.println("");
        System.out.println("Forth element of the array list: "+ranks.get(3));
        System.out.println("");
        System.out.println("Fifth element of the array list: "+ranks.get(4));
         break;  //optional    
        case 2:ranks.remove(1);
        System.out.println("First element of the array list: "+ranks.get(0));
        System.out.println("");
        System.out.println("second element of the array list: "+ranks.get(1));
        System.out.println("");
        System.out.println("third  element of the array list: "+ranks.get(2));
        System.out.println("");
        System.out.println("Forth element of the array list: "+ranks.get(3));
        System.out.println("");
        System.out.println("Fifth element of the array list: "+ranks.get(4));      
        
         break; 
        case 3:ranks.remove(2);
        System.out.println("First element of the array list: "+ranks.get(0));
        System.out.println("");
        System.out.println("second element of the array list: "+ranks.get(1));
        System.out.println("");
        System.out.println("third  element of the array list: "+ranks.get(2));
        System.out.println("");
        System.out.println("Forth element of the array list: "+ranks.get(3));
        System.out.println("");
        System.out.println("Fifth element of the array list: "+ranks.get(4));      
            break;  //optional    
        case 4:ranks.remove(3);
        System.out.println("First element of the array list: "+ranks.get(0));
        System.out.println("");
        System.out.println("second element of the array list: "+ranks.get(1));
        System.out.println("");
        System.out.println("third  element of the array list: "+ranks.get(2));
        System.out.println("");
        System.out.println("Forth element of the array list: "+ranks.get(3));
        System.out.println("");
        System.out.println("Fifth element of the array list: "+ranks.get(4));
            break;
           case 5:ranks.remove(4);
           System.out.println("First element of the array list: "+ranks.get(0));
           System.out.println("");
           System.out.println("second element of the array list: "+ranks.get(1));
           System.out.println("");
           System.out.println("third  element of the array list: "+ranks.get(2));
           System.out.println("");
           System.out.println("Forth element of the array list: "+ranks.get(3));
           System.out.println("");
           System.out.println("Fifth element of the array list: "+ranks.get(4));     
            break; 
            }
      }else if(choice.equals("all")){
    		ranks.remove(0);
    		ranks.remove(1);
    		ranks.remove(2);
    		ranks.remove(3);
    		ranks.remove(4);
    		System.out.println("First element of the array list: "+ranks.get(0));
            System.out.println("");
            System.out.println("second element of the array list: "+ranks.get(1));
            System.out.println("");
            System.out.println("third  element of the array list: "+ranks.get(2));
            System.out.println("");
            System.out.println("Forth element of the array list: "+ranks.get(3));
            System.out.println("");
            System.out.println("Fifth element of the array list: "+ranks.get(4)); 
      } else if(choice.equals("none" )){
    	  ArrayList<String>
    	    arrlist = new ArrayList<String>();

    	// Populating arrlist1
    	arrlist.add(ranks.get(0));
    	arrlist.add(ranks.get(1));
    	arrlist.add(ranks.get(2));
    	arrlist.add(ranks.get(3));
    	arrlist.add(ranks.get(4));
    	  a=20;
    	  int score=0;
    	  if (arrlist.contains("Ace Hearts") && arrlist.contains("King Hearts") && arrlist.contains("Queen Hearts") && arrlist.contains("Jack Hearts") && arrlist.contains("Ten Hearts")) {
    		    score += 250;
    		    System.out.println("You got a Royal Flush! Your score is: " + score);
    		    
    		}else if (arrlist.contains("Ace Clubs") && arrlist.contains("King Clubs") && arrlist.contains("Queen Clubs") && arrlist.contains("Jack Clubs") && arrlist.contains("Ten Clubs")) {
    		    score += 250;
    		    System.out.println("You got a Royal Flush! Your score is: " + score);
    		}
    		else if (arrlist.contains("Ace Spades") && arrlist.contains("King Spades") && arrlist.contains("Queen Spades") && arrlist.contains("Jack Spades") && arrlist.contains("Ten Spades")) {
    		    score += 250;
    		    System.out.println("You got a Royal Flush! Your score is: " + score);
    		}
    		else if (arrlist.contains("Ace Diamonds") && arrlist.contains("King Diamonds") && arrlist.contains("Queen Diamonds") && arrlist.contains("Jack Diamonds") && arrlist.contains("Ten Diamonds")) {
    		    score += 250;
    		    System.out.println("You got a Royal Flush! Your score is: " + score);
    		}
    		
    	 
    		 // check for straight flush in hearts
    		    for (int i = 10; i >= 6; i--) {
    		        if (arrlist.contains(i + " Hearts") && arrlist.contains((i + 1) + " Hearts") && arrlist.contains((i + 2) + " Hearts") && arrlist.contains((i + 3) + " Hearts") && arrlist.contains((i + 4) + " Hearts")) {
    		           
    		            System.out.println("You got a Straight Flush! Your score is: " + "50");
    		            
    		        }
    		    
    		        else if  (arrlist.contains(i + " Clubs") && arrlist.contains((i + 1) + " Clubs") && arrlist.contains((i + 2) + " Clubs") && arrlist.contains((i + 3) + " Clubs") && arrlist.contains((i + 4) + " Clubs")) {
    		            
    		            System.out.println("You got a Straight Flush! Your score is: " + "50");
    		            
    		        }
    		    
    		   
    		    	else if  (arrlist.contains(i + " Spades") && arrlist.contains((i + 1) + " Spades") && arrlist.contains((i + 2) + " Spades") && arrlist.contains((i + 3) + " Spades") && arrlist.contains((i + 4) + " Spades")) {
    		           
    		            System.out.println("You got a Straight Flush! Your score is: " + "50");
    		            
    		        }
    		    
    		    
    		    	else if (arrlist.contains(i + " Diamonds") && arrlist.contains((i + 1) + " Diamonds") && arrlist.contains((i + 2) + " Diamonds") && arrlist.contains((i + 3) + " Diamonds") && arrlist.contains((i + 4) + " Diamonds")) {
    		           
    		            System.out.println("You got a Straight Flush! Your score is: " + "50");
    		            
    		        }
    		    }
    		 // check for four of a kind
    		    for (int i = 14; i >= 2; i--) {
    		        int count = 0;
    		        for (int j = 0; j < arrlist.size(); j++) {
    		            if (arrlist.get(j).contains(i + "Spades")) {
    		                count++;
    		            }
    		        }
    		        if (count == 4) {
    		            
    		            System.out.println("You got Four of a Kind! Your score is: " + "25");
    		            break;
    		        }
    		    }

    for (int i = 14; i >= 2; i--) {
        int count = 0;
        for (int j = 0; j < arrlist.size(); j++) {
            if (arrlist.get(j).contains(i + "Hearts")) {
                count++;
            }
        }
        if (count == 4) {
            
            System.out.println("You got Four of a Kind! Your score is: " + "25");
            break;
        }
    }


    for (int i = 14; i >= 2; i--) {
        int count = 0;
        for (int j = 0; j < arrlist.size(); j++) {
            if (arrlist.get(j).contains(i + "Diamonds")) {
                count++;
            }
        }
        if (count == 4) {
            
            System.out.println("You got Four of a Kind! Your score is: " + "25");
            break;
        }
    }
    for (int i = 14; i >= 2; i--) {
        int count = 0;
        for (int j = 0; j < arrlist.size(); j++) {
            if (arrlist.get(j).contains(i + "Clubs")) {
                count++;
            }
        }
        if (count == 4) {
            
            System.out.println("You got Four of a Kind! Your score is: " + "25");
            break;
        }
    }
    //three
    for (int i = 14; i >= 2; i--) {
        int count = 0;
        for (int j = 0; j < arrlist.size(); j++) {
            if (arrlist.get(j).contains(i + "Spades")) {
                count++;
            }
        }
        if (count == 3) {
            
            System.out.println("You got Four of a Kind! Your score is: " + "3");
            break;
        }
    }
    for (int i = 14; i >= 2; i--) {
    	int count = 0;
    	for (int j = 0; j < arrlist.size(); j++) {
    	if (arrlist.get(j).contains(i + "Hearts")) {
    	    count++;
    	}
    	}
    	if (count == 3) {

    	System.out.println("You got Four of a Kind! Your score is: " + "3");
    	break;
    	}
    	}

    	for (int i = 14; i >= 2; i--) {
    	int count = 0;
    	for (int j = 0; j < arrlist.size(); j++) {
    	if (arrlist.get(j).contains(i + "Diamonds")) {
    	    count++;
    	}
    	}
    	if (count == 3) {

    	System.out.println("You got Four of a Kind! Your score is: " + "3");
    	break;
    	}
    	}
    	for (int i = 14; i >= 2; i--) {
    	int count = 0;
    	for (int j = 0; j < arrlist.size(); j++) {
    	if (arrlist.get(j).contains(i + "Clubs")) {
    	    count++;
    	}
    	}
    	if (count == 3) {

    	System.out.println("You got three of a Kind! Your score is: " + "3");
    	break;          
    	}
    	}
    
    	// check for straight in hearts
    	for (int i = 10; i >= 5; i--) {
    	    if (arrlist.contains(i + " Hearts") && arrlist.contains((i - 1) + " Hearts") && arrlist.contains((i - 2) + " Hearts") && arrlist.contains((i - 3) + " Hearts") && arrlist.contains((i - 4) + " Hearts")) {
    	      
    	        System.out.println("You got a Straight! Your score is: " + "4");
    	        break;
    	    }
    	}

    	// check for straight in clubs
    	for (int i = 10; i >= 5; i--) {
    	    if (arrlist.contains(i + " Clubs") && arrlist.contains((i - 1) + " Clubs") && arrlist.contains((i - 2) + " Clubs") && arrlist.contains((i - 3) + " Clubs") && arrlist.contains((i - 4) + " Clubs")) {
    	        score += 4;
    	        System.out.println("You got a Straight! Your score is: " + "4");
    	        break;
    	    }
    	}
    	for (int i = 10; i >= 5; i--) {
    	    if (arrlist.contains(i + " Diamonds") && arrlist.contains((i - 1) + " Diamonds") && arrlist.contains((i - 2) + " Diamonds") && arrlist.contains((i - 3) + " Diamonds") && arrlist.contains((i - 4) + " Diamonds")) {
    	      
    	        System.out.println("You got a Straight! Your score is: " + "4");
    	        break;
    	    }
    	}

    
    	for (int i = 10; i >= 5; i--) {
    	    if (arrlist.contains(i + " Spades") && arrlist.contains((i - 1) + " Spades") && arrlist.contains((i - 2) + " Spades") && arrlist.contains((i - 3) + " Spades") && arrlist.contains((i - 4) + " Spades")) {
    	        score += 4;
    	        System.out.println("You got a Straight! Your score is: " + "4");
    	        break;
    	    }
    	}
    }
}

}

}
 // check for full house
   /* for (int b = 14; b >= 2; b--) {
        int counter = 0;
        for (int j = 0; j < arrlist.size(); j++) {
            if (arrlist.get(j).contains(b + "")) {
                count++;
            }
        }
        if (count == 3) {
            for (int k = 14; k >= 2; k--) {
                int count2 = 0;
                for (int l = 0; l < ranks.size(); l++) {
                    if (arrlist.get(l).contains(k + "")) {
                        count2++;
                    }
                }
                if (count2 == 2) {
                   
                    System.out.println("You got a Full House! Your score is: " + "6");
                    break;
                }
            }
            break;
        }
    }
    
    
 	   
 	
 

    
    
    
  
    
/*for( int i =0 ;i< deck.length; i++) { deck[i]= i; 

}
 
 for( int i = 0;i < deck.length; i++) {
	int  index = (int)(Math.random()* deck.length);
	int temp = deck[i];
	deck[i]=deck [index];
	deck[index]=temp;
	 }
    for(int i=0; i < 52; i++) {
  	 // String suit = suits[deck[i] / 13];
       // String rank = ranks[deck[i] % 13];
}
/*String[] suits = {"Hearts", "Clubs", "Spades", "Diamonds"};
 * // String[] ranks = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};  
 */
  
//  int[] deck = new int [52]; 

// Creating an empty ArrayList of string type
/*ArrayList<String> suits = new ArrayList<String>();

// Adding custom input elements to list object
suits.add("Hearts");
suits.add("Clubs");
suits.add("Spades");
suits.add("Diamonds");

*/


// Shuffling the list
//Collections.shuffle(suits);

//4.6Design and implement a class called Card
//that represents a standard playing card. Each card has a suit and a face value. 
//Create a program that deals 20 random card.