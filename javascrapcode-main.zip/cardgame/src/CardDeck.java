import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


      