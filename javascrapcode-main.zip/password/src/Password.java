import java.util.*;

public class Password {
    public static void main(String[] args) {
        final String PASSWORD = "hello";
        boolean wrongPass = true;

        for (int passAttempts = 0; passAttempts < 3 && wrongPass; passAttempts++) {
            System.out.println("Enter Your Password: ");
            Scanner input = new Scanner(System.in);
            String inputPass = input.nextLine();
          

            if (!(inputPass.equals(PASSWORD))) {
                System.out.println("typed password is incorrect");
            } else if (inputPass.equals(PASSWORD))   {
                System.out.println("correct password");
                wrongPass = false;
            }
             if (passAttempts>=2 && (!(inputPass.equals(PASSWORD))) )    {
                System.out.println("access denied");
                wrongPass = false;
                input.close();
                
            }
           
        }
        
    }
}