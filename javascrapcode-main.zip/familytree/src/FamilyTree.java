
public class FamilyTree{
	public static void main(String [] args){
		//my mom parents
	TreeNode grandmaha = new TreeNode("Sabitri Ghrime",null,null);
	
	TreeNode grandpaha = new TreeNode("Keshave Ghimire",null,null);
	
	//my dad parents
	TreeNode grandma = new TreeNode("Kamala Neupane",null,null); 
	TreeNode grandpa = new TreeNode("Rishiram neupane",null,null);
	
	TreeNode mom = new TreeNode("Laltia Neupane",grandmaha,grandpaha); 
	
	TreeNode dad = new TreeNode("Kapil Neupane",grandma,grandpa);
	//me 
	TreeNode me = new TreeNode("Ankit Neupane",mom,dad);
	
	System.out.println(me.getValue()+"'s Family Tree");
	printTree(me);

	}
	
	private static void printTree(TreeNode current )
	{
	if(current.getLeft()!=null)
	{
		System.out.println(current.getValue()+"'s Mother is "+ current.getLeft().getValue());
		printTree(current.getLeft());
	}
	
	if(current.getRight()!=null)
	{
		System.out.println(current.getValue()+"'s Father is "+ current.getRight().getValue());
		printTree(current.getRight());
	}
	
	
	
	
}
}

