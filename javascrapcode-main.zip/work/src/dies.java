
public class dies {
	int a;
	public dies(int sides ) {
		a=sides;
	}
	
	public int b () {
		return ((int)(Math.random()*a+1));
	}
}
