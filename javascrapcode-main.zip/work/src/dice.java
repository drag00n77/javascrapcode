
import java.util.Scanner;


//name of game 
public class dice{ 
	
	
	
	public static  void main(String[ ] args) {
		boolean right = true;
		do { 
			
			
			Scanner input = new Scanner (System.in);  // Create a Scanner object
			System.out.println("number of sides on two dices: "); 
	   	    int a =input.nextInt();
	   	    dies c= new dies(a);
	   		
	     
	    
	   	    int dicea=(int)(Math.random()*a+1);
   
	   	    System.out.println ("you got "+c.b());
	   	 if ()    
		} while (right);
		
		 input.close();
				
			
				/*do {
					System.out.println("Do you want to continue y or n");
					 
					    c = input.nextLine();
				    
					}
					while( input.nextLine().toUpperCase().equals("Y"));
					
					 input.close();
			          
			        } 
				}
                */
				
	}
	}
	       
	

	        
	    
	      