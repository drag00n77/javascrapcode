public class CDItem implements Comparable<CDItem>{
    String title;
    String singer;
    double price;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getSinger() {
        return singer;
    }
    public void setSinger(String singer) {
        this.singer = singer;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String toString() {
    	return title+("  ")+singer+("   ")+price +(" ");
    }
    CDItem(String title, String singer, double price){
        this.title=title;
        this.singer=singer;
        this.price=price;
    }

    public int compareTo(CDItem item){
        return this.title.compareTo(item.title);
    }
}


