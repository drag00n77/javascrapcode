import java.util.ArrayList;
import java.util.Collections;

public class CDCollection{
  
	ArrayList<CDItem> list =  new ArrayList<CDItem>();
    public void addCD(String title, String singer, double price){
    	
    	CDItem item=new CDItem(title, singer, price);
    	list.add(item);
    }

    public String toString(){
        String result="";
       
		for(int i=0; i<list.size(); i++){
         CDItem item=(CDItem)list.get(i);
            result=result + "|" + item; 
        }

        return result;
    }

    public void sort(){
        Collections.sort(list);
 }
}