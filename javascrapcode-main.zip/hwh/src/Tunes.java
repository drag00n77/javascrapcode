public class Tunes {
    public static void main(String[] args) {
        CDCollection music = new CDCollection ();

        music.addCD ("By the Way", "Red Hot Chili Peppers", 14.95);
        music.addCD ("Come On Over", "Shania Twain", 14.95);
        music.addCD ("Soundtrack", "The Producers", 17.95);
        music.addCD ("Play", "Jennifer Lopez", 13.90);

       // System.out.println (music);

        music.addCD ("Double Live", "Garth Brooks", 19.99);
        music.addCD ("Greatest Hits", "Stone Temple Pilots", 15.95);

       // System.out.println (music);

        music.sort();
        System.out.println (music);
    }   
}
