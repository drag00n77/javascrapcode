public class classproject {
	  public static void main(String[] args) {
		  
	  }
}