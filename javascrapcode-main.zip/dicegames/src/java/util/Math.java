package java.util;

public class Math {

}
