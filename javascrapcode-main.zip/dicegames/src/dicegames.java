import java.util.Scanner;

import java.util.Scanner;
public class dicegames{
public static void main(String[]args) {

Scanner input = new Scanner(System.in);
System.out.print("the number of sides ");
float a=input.nextFloat();
input.close();
        int sum = (dice1 + dice2);
        switch (sum) {
          case 1:
            System.out.println("you got 1");
            break;
          case 2:
            System.out.println("you got 2");
            break;
          case 3:
            System.out.println("you got 3");
            break;
          case 4:
            System.out.println("you got 4");
            break;
          case 5:
            System.out.println("you got 5");
            break;
          case 6:
            System.out.println("you got 6");
            break;
          case 7:
            System.out.println("you got 7");
            break;
          case 8:
             System.out.println("you got 8");
             break;
          case 9:
             System.out.println("you got 9");
             break;
          case 10:
             System.out.println("you got 10");
             break;
           case 11:
             System.out.println("you got 11");
              break;
           case 12:
             System.out.println("you got 12");
              break; }
        
    	   }
      }

    	  
   
