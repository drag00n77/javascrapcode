abstract class Vehicle{
private int wheelsize;
private int engiesize;
private int numseats;

public Vehicle(int Wsize,int Esize,int steating) {
	wheelsize= Wsize;
	engiesize= Esize;
	numseats= steating;
	
}
public int getWsize() {
	return(wheelsize);
}
public int getEsize() {
	return(engiesize);
}
public int getnumseats() {
	return(numseats);
}


abstract String description();
}