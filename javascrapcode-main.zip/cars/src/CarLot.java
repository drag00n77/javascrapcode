import java.util.Scanner;
public class CarLot{
public static Vechicle add Vehicle() {
}
