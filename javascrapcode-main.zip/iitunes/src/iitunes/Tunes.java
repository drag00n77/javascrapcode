package iitunes;

import java.util.ArrayList;
import java.util.Collections;

public class Tunes
{
//-----------------------------------------------------------------
// Creates a CDCollection object and adds some CDs to it. Prints
// reports on the status of the collection.
//-----------------------------------------------------------------
public static void main (String[] args)
{
	ArrayList<String> CD = new ArrayList<String>();
CD.add ("By the Way");
CD.add ("Come On Over");
CD.add ("Soundtrack");
CD.add ("Play");

CD.add ("Double Live");
CD.add ("Greatest Hits");


Collections.sort(CD);

// Let us print the sorted list
System.out.println("List of"
                   + "titles :\n" + CD);
}
}


