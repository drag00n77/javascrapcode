import java.util.Scanner;
public class dicerollgame
{
 
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
int min = 2;
 
int max = 12;
 
int score = 1000;
 
int output;
 
System.out.println("Dice roll game \n\nRULES\nNumbers 2-6 are low\nNumbers 8-12 are high\nNumber 7 is neither high or low");
do {
System.out.println("\n\nYou have " + score + " points.\n\nEnter points to risk: ");
int player = input.nextInt();
while (player > score){
	//" player Enter a value correlating  score.");
player = input.nextInt();
}

System.out.print("\nPredict <1=High roll , 0=Low roll>: ");
int predict = input.nextInt();
 
int rana = (int)Math.floor(Math.random()*(6-min+1)+min);
int ran = (int)Math.floor(Math.random()*(6-min+1)+min);
int rand = rana + ran;
System.out.println("you rolled a "+rand+".");
if (rand >= 2 && rand <= 6) {
output = 0;
} else if (rand >= 8 && rand <= 12) {
output = 1;
}else {
output = 9000;
}
 
if (predict == 1 && output == 1) {
System.out.println("You Win!");
score = (score + (player*2));
}else if (predict == 0 && output == 0) {
System.out.println("You Win!");
score = (score + (player*2));

}else if (rand == 7 ){
System.out.println("it is neither...");
score = (score-player);
System.out.println( score + " score is left " );
}else {
System.out.println("You lose.");
score = (score-player);
System.out.println( score + " score is left ");
}
 
System.out.printf("Play Again? (1:yes  -1:no:) ");
int playAgain = input.nextInt();
if (score <= 0) {
System.out.println("You have no more points.");
break;
}else if (playAgain == 1){
}else {
break;
}
} while (score > 0);
 
System.out.println("Game Over.");
input.close();
}
}
